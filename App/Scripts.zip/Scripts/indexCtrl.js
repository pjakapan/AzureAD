﻿'use strict';
angular.module('catApp')
.controller('indexCtrl', ['$scope', 'adalAuthenticationService', function ($scope, adalService) {


}]);