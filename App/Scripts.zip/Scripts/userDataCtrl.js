﻿'use strict';
angular.module('catApp')
.controller('userDataCtrl', ['$scope', 'adalAuthenticationService', function ($scope, adalService) {


}]);